

## Title 标题
> **组件名：uni-title**
> 代码块： `uTitle`


章节标题，通常用于记录页面标题，使用当前组件，uni-app 如果开启统计，将会自动统计页面标题 。

### [查看文档](https://uniapp.dcloud.io/component/uniui/uni-title)
#### 如使用过程中有任何问题，或者您对uni-ui有一些好的建议，欢迎加入 uni-ui 交流群：871950839 



