## Layout 布局

> **组件名 uni-row、uni-col**
> 代码块： `uRow`、`uCol`


流式栅格系统，随着屏幕或视口分为 24 份，可以迅速简便地创建布局。

### [查看文档](https://uniapp.dcloud.io/component/uniui/uni-row)
#### 如使用过程中有任何问题，或者您对uni-ui有一些好的建议，欢迎加入 uni-ui 交流群：871950839 